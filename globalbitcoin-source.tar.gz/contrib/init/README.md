Sample configuration files for:
```
SystemD: globalbitcoind.service
Upstart: globalbitcoind.conf
OpenRC:  globalbitcoind.openrc
         globalbitcoind.openrcconf
CentOS:  globalbitcoind.init
macOS:    org.globalbitcoin.globalbitcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
